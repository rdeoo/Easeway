import { useState, type ReactNode } from "react";

type Screen =
  | "login"
  | "home"
  | "commutes"
  | "add"
  | "route"
  | "alerts"
  | "profile";

type IconName =
  | "home"
  | "calendar"
  | "bell"
  | "user"
  | "arrow"
  | "pin"
  | "car"
  | "clock"
  | "traffic"
  | "plus"
  | "more"
  | "edit"
  | "trash"
  | "walk"
  | "train"
  | "bike"
  | "settings"
  | "shield"
  | "logout"
  | "chevron"
  | "check"
  | "location"
  | "swap"
  | "briefcase"
  | "close";

const iconPaths: Record<IconName, ReactNode> = {
  home: <><path d="M3 11.5 12 4l9 7.5" /><path d="M5.5 10v10h13V10M9 20v-6h6v6" /></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="3" /><path d="M8 3v4M16 3v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01" /></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  arrow: <><path d="m15 18-6-6 6-6" /></>,
  pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
  car: <><path d="m5 17-1 2M19 17l1 2M5 17h14v-6l-2-5H7l-2 5v6Z" /><path d="M5 11h14M8 14h.01M16 14h.01" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  traffic: <><path d="M8 3h8v18H8z" /><circle cx="12" cy="7" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="12" cy="17" r="1.5" /></>,
  plus: <><path d="M12 5v14M5 12h14" /></>,
  more: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
  edit: <><path d="m4 20 4-.8L19 8.3 15.7 5 4.8 15.9 4 20ZM14 6.5l3.5 3.5" /></>,
  trash: <><path d="M5 7h14M9 7V4h6v3M7 7l1 14h8l1-14M10 11v6M14 11v6" /></>,
  walk: <><circle cx="13" cy="4" r="2" /><path d="m10 21 2-6-3-3 2-5 4 3 3 1M14 14l4 7M9 12l-3 4" /></>,
  train: <><rect x="5" y="3" width="14" height="15" rx="3" /><path d="M8 21l2-3M16 18l2 3M5 9h14M9 14h.01M15 14h.01" /></>,
  bike: <><circle cx="6" cy="17" r="4" /><circle cx="18" cy="17" r="4" /><path d="m6 17 4-7 3 7h-7ZM10 10h5l3 7M9 7h3" /></>,
  settings: <><circle cx="12" cy="12" r="3" /><path d="M19 13.5V10l-2-.7-.8-1.8.9-1.9-2.5-2.5-1.9.9-2-.8L10 1H6.5l-.7 2.2-1.9.8-2-.9L-.6 5.6l1 1.9-.8 1.8-2 .7v3.5l2 .7.8 1.8-1 2 2.5 2.5 2-.9 1.9.8.7 2.1H10l.7-2.1 2-.8 1.9.9 2.5-2.5-.9-2 1-1.8 1.8-.7Z" transform="translate(2.5 .2) scale(.78)" /></>,
  shield: <><path d="M12 3 4.5 6v5c0 5 3.2 8.5 7.5 10 4.3-1.5 7.5-5 7.5-10V6L12 3Z" /><path d="m9 12 2 2 4-4" /></>,
  logout: <><path d="M10 5H5v14h5M14 8l4 4-4 4M8 12h10" /></>,
  chevron: <><path d="m9 18 6-6-6-6" /></>,
  check: <><path d="m5 12 4 4L19 6" /></>,
  location: <><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3" /></>,
  swap: <><path d="M7 7h12l-3-3M17 17H5l3 3" /></>,
  briefcase: <><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M9 7V4h6v3M3 12h18M10 12v2h4v-2" /></>,
  close: <><path d="m6 6 12 12M18 6 6 18" /></>,
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  return (
    <svg
      aria-hidden="true"
      className="icon"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {iconPaths[name]}
    </svg>
  );
}

function Toggle({
  active,
  onClick,
  label,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      className={`toggle ${active ? "active" : ""}`}
      onClick={onClick}
      aria-label={label}
      aria-pressed={active}
    >
      <span />
    </button>
  );
}

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`logo ${compact ? "compact" : ""}`}>
      <span className="logo-mark"><span /></span>
      {!compact && <strong>Easeway</strong>}
    </div>
  );
}

function MapPreview({ detailed = false }: { detailed?: boolean }) {
  return (
    <div className={`map ${detailed ? "map-detailed" : ""}`}>
      <svg viewBox="0 0 400 260" preserveAspectRatio="none" aria-label="Route map from home to BCIT Burnaby">
        <rect width="400" height="260" fill="#edf2ed" />
        <path className="water" d="M-20 220C72 166 142 259 231 205s140-19 190-3v80H-20Z" />
        <g className="minor-roads">
          <path d="M-10 48 420 170M-10 106l430 70M43-10 72 280M132-10l-29 290M225-10l9 280M315-10l-44 280M-20 191 420 65M-10 148 405 24" />
        </g>
        <g className="major-roads">
          <path d="M-10 182C81 166 115 102 187 120s108 12 233-73" />
          <path d="M62-10c6 78 50 113 92 141s77 71 80 146" />
        </g>
        <path className="route-shadow" d="M58 207c24-55 60-54 87-82 30-31 40-62 88-54 38 6 55 5 93-23" />
        <path className="route-line" d="M58 207c24-55 60-54 87-82 30-31 40-62 88-54 38 6 55 5 93-23" />
        <path className="traffic-line" d="M146 124c29-30 40-61 87-53" />
        <circle cx="58" cy="207" r="12" fill="white" />
        <circle cx="58" cy="207" r="7" fill="#2677f2" />
        <g transform="translate(313 27)">
          <path d="M13 2C6.4 2 2 6.8 2 12.4 2 20 13 29 13 29s11-9 11-16.6C24 6.8 19.6 2 13 2Z" fill="#1769e0" />
          <circle cx="13" cy="12" r="4" fill="white" />
        </g>
      </svg>
      {!detailed && <div className="map-chip"><Icon name="car" size={15} /> 45 min</div>}
      {detailed && (
        <>
          <button className="map-control map-layers" aria-label="Map layers"><Icon name="settings" /></button>
          <button className="map-control map-location" aria-label="Current location"><Icon name="location" /></button>
        </>
      )}
    </div>
  );
}

function TopBar({
  title,
  onBack,
  action,
}: {
  title: string;
  onBack?: () => void;
  action?: ReactNode;
}) {
  return (
    <header className="topbar">
      {onBack ? (
        <button className="icon-button" onClick={onBack} aria-label="Go back"><Icon name="arrow" /></button>
      ) : <Logo />}
      <div className="topbar-title">{title}</div>
      <div className="topbar-action">{action}</div>
    </header>
  );
}

function Login({ onEnter }: { onEnter: () => void }) {
  const [register, setRegister] = useState(false);
  return (
    <div className="login-screen">
      <div className="login-visual">
        <Logo />
        <div className="route-art" aria-hidden="true">
          <span className="art-dot start" />
          <span className="art-route" />
          <span className="art-pin"><Icon name="pin" size={28} /></span>
          <span className="art-car"><Icon name="car" size={23} /></span>
        </div>
      </div>
      <div className="login-panel">
        <span className="eyebrow">Smarter everyday travel</span>
        <h1>{register ? "Create your account" : "Arrive on time, every time."}</h1>
        <p className="lead">
          {register
            ? "Set up your commute plan in just a minute."
            : "Easeway watches traffic and tells you exactly when it’s time to leave."}
        </p>
        <div className="form-stack">
          {register && (
            <label className="field">
              <span>Name</span>
              <input type="text" defaultValue="Alex Morgan" />
            </label>
          )}
          <label className="field">
            <span>Email</span>
            <input type="email" placeholder="you@example.com" defaultValue={register ? "alex@example.com" : ""} />
          </label>
          <label className="field">
            <span>Password</span>
            <input type="password" placeholder="At least 8 characters" defaultValue={register ? "easeway123" : ""} />
          </label>
          <button className="primary-button" onClick={onEnter}>
            {register ? "Create account" : "Sign in"}
            <Icon name="chevron" />
          </button>
        </div>
        <button className="text-button" onClick={() => setRegister(!register)}>
          {register ? "Already have an account? Sign in" : "New to Easeway? Create an account"}
        </button>
        <p className="terms">By continuing, you agree to our Terms and Privacy Policy.</p>
      </div>
    </div>
  );
}

function Dashboard({ navigate }: { navigate: (screen: Screen) => void }) {
  return (
    <div className="screen">
      <TopBar
        title=""
        action={<button className="avatar" onClick={() => navigate("profile")}>AM</button>}
      />
      <main className="content home-content">
        <div className="welcome-row">
          <div>
            <p className="overline">TUESDAY, MAY 14</p>
            <h1>Good morning, Alex</h1>
          </div>
          <span className="weather">14°</span>
        </div>

        <section className="departure-card">
          <div className="card-topline">
            <span className="status-pill"><span /> On track</span>
            <span className="muted">Work commute</span>
          </div>
          <p className="departure-label">Leave home at</p>
          <div className="departure-time">7:28 <small>AM</small></div>
          <p className="departure-countdown">in 24 minutes</p>
          <div className="journey-line">
            <div className="journey-point"><span className="point home-point"><Icon name="home" size={14} /></span><strong>Home</strong></div>
            <span className="dotted-line" />
            <span className="journey-car"><Icon name="car" size={17} /></span>
            <span className="dotted-line" />
            <div className="journey-point end"><span className="point work-point"><Icon name="briefcase" size={14} /></span><strong>BCIT</strong></div>
          </div>
          <button className="route-button" onClick={() => navigate("route")}>
            View route <Icon name="chevron" size={18} />
          </button>
        </section>

        <section className="card trip-summary">
          <div className="section-heading">
            <div>
              <p className="overline">NEXT COMMUTE</p>
              <h2>BCIT Burnaby</h2>
              <p className="address"><Icon name="pin" size={14} /> 3700 Willingdon Ave</p>
            </div>
            <span className="arrival-badge">Arrive 8:30 AM</span>
          </div>
          <MapPreview />
          <div className="metric-grid">
            <div><span className="metric-icon blue"><Icon name="traffic" /></span><p>Live traffic</p><strong>45 min</strong></div>
            <div><span className="metric-icon violet"><Icon name="clock" /></span><p>Adjustment</p><strong>+7 min</strong></div>
            <div><span className="metric-icon green"><Icon name="car" /></span><p>Parking</p><strong>10 min</strong></div>
          </div>
        </section>

        <div className="traffic-note">
          <span className="traffic-dot" />
          <div><strong>Moderate traffic</strong><p>8 minutes slower than usual on Highway 1</p></div>
          <Icon name="chevron" size={18} />
        </div>
      </main>
    </div>
  );
}

type Commute = { id: number; name: string; destination: string; days: string; time: string; duration: string; enabled: boolean; icon: IconName };

const initialCommutes: Commute[] = [
  { id: 1, name: "Work", destination: "BCIT Burnaby", days: "Mon–Fri", time: "8:30 AM", duration: "45 min", enabled: true, icon: "briefcase" },
  { id: 2, name: "Tuesday class", destination: "SFU Burnaby Campus", days: "Tuesday", time: "6:00 PM", duration: "32 min", enabled: true, icon: "calendar" },
  { id: 3, name: "Gym", destination: "Brentwood Fitness", days: "Mon, Wed, Fri", time: "5:30 PM", duration: "18 min", enabled: false, icon: "car" },
];

function Commutes({
  navigate,
  commutes,
  setCommutes,
}: {
  navigate: (screen: Screen) => void;
  commutes: Commute[];
  setCommutes: (items: Commute[]) => void;
}) {
  const toggle = (id: number) => setCommutes(commutes.map(c => c.id === id ? { ...c, enabled: !c.enabled } : c));
  const remove = (id: number) => setCommutes(commutes.filter(c => c.id !== id));
  return (
    <div className="screen">
      <TopBar
        title="My Commutes"
        action={<button className="icon-button blue-button" onClick={() => navigate("add")} aria-label="Add commute"><Icon name="plus" /></button>}
      />
      <main className="content">
        <div className="page-intro">
          <h1>Your weekly routine</h1>
          <p>We’ll keep an eye on traffic for every enabled commute.</p>
        </div>
        <div className="commute-list">
          {commutes.map((commute) => (
            <section className={`commute-card ${!commute.enabled ? "disabled" : ""}`} key={commute.id}>
              <div className="commute-head">
                <span className="commute-icon"><Icon name={commute.icon} /></span>
                <div className="grow"><h2>{commute.name}</h2><p>{commute.destination}</p></div>
                <Toggle active={commute.enabled} onClick={() => toggle(commute.id)} label={`${commute.enabled ? "Disable" : "Enable"} ${commute.name}`} />
              </div>
              <div className="commute-meta">
                <span><Icon name="calendar" size={15} /> {commute.days}</span>
                <span><Icon name="clock" size={15} /> Arrive {commute.time}</span>
                <span><Icon name="car" size={15} /> {commute.duration}</span>
              </div>
              <div className="card-actions">
                <button onClick={() => navigate("route")}><Icon name="pin" size={16} /> View route</button>
                <button onClick={() => navigate("add")}><Icon name="edit" size={16} /> Edit</button>
                <button className="delete-action" onClick={() => remove(commute.id)} aria-label={`Delete ${commute.name}`}><Icon name="trash" size={17} /></button>
              </div>
            </section>
          ))}
        </div>
        <button className="outline-button full" onClick={() => navigate("add")}><Icon name="plus" /> Add a commute</button>
      </main>
    </div>
  );
}

function AddCommute({
  onBack,
  onSave,
}: {
  onBack: () => void;
  onSave: () => void;
}) {
  const [days, setDays] = useState(["M", "T", "W", "T2", "F"]);
  const [mode, setMode] = useState("car");
  const toggleDay = (day: string) => setDays(days.includes(day) ? days.filter(d => d !== day) : [...days, day]);
  return (
    <div className="screen">
      <TopBar title="Add commute" onBack={onBack} action={<button className="save-link" onClick={onSave}>Save</button>} />
      <main className="content form-content">
        <div className="location-fields">
          <span className="location-rail"><i /><b /></span>
          <label className="field">
            <span>FROM</span>
            <input defaultValue="Home · 1285 East 14th Ave" />
          </label>
          <button className="swap-button" aria-label="Swap origin and destination"><Icon name="swap" /></button>
          <label className="field">
            <span>TO</span>
            <input defaultValue="BCIT Burnaby" />
          </label>
        </div>

        <section className="form-section">
          <div className="form-title"><span className="metric-icon blue"><Icon name="calendar" /></span><div><h2>Repeat</h2><p>Select your commute days</p></div></div>
          <div className="day-picker">
            {[["M", "M"], ["T", "T"], ["W", "W"], ["T2", "T"], ["F", "F"], ["S", "S"], ["S2", "S"]].map(([key, label]) => (
              <button key={key} onClick={() => toggleDay(key)} className={days.includes(key) ? "selected" : ""}>{label}</button>
            ))}
          </div>
        </section>

        <section className="form-section">
          <div className="form-title"><span className="metric-icon violet"><Icon name="clock" /></span><div><h2>Arrive by</h2><p>We’ll calculate when to leave</p></div></div>
          <button className="time-picker"><span>8:30</span><small>AM</small></button>
        </section>

        <section className="form-section">
          <div className="form-title"><span className="metric-icon green"><Icon name="car" /></span><div><h2>Travel mode</h2><p>Choose how you’re getting there</p></div></div>
          <div className="mode-picker">
            {([["car", "car", "Drive"], ["train", "train", "Transit"], ["bike", "bike", "Bike"], ["walk", "walk", "Walk"]] as [string, IconName, string][]).map(([key, icon, label]) => (
              <button key={key} onClick={() => setMode(key)} className={mode === key ? "selected" : ""}><Icon name={icon} /><span>{label}</span></button>
            ))}
          </div>
        </section>

        <section className="form-section">
          <div className="form-title"><span className="metric-icon amber"><Icon name="clock" /></span><div><h2>Extra time</h2><p>Plan for parking and walking in</p></div></div>
          <div className="buffer-row"><span>Arrival buffer</span><div className="stepper"><button>−</button><strong>10 min</strong><button>+</button></div></div>
        </section>
        <button className="primary-button" onClick={onSave}><Icon name="check" /> Save commute</button>
      </main>
    </div>
  );
}

function RouteDetails({ onBack }: { onBack: () => void }) {
  const [route, setRoute] = useState(0);
  return (
    <div className="screen route-screen">
      <div className="route-map-wrap">
        <MapPreview detailed />
        <header className="floating-topbar">
          <button className="icon-button" onClick={onBack} aria-label="Go back"><Icon name="arrow" /></button>
          <div><strong>BCIT Burnaby</strong><span>Arrive by 8:30 AM</span></div>
          <button className="icon-button" aria-label="More options"><Icon name="more" /></button>
        </header>
      </div>
      <main className="route-sheet">
        <span className="sheet-handle" />
        <div className="route-primary">
          <div>
            <span className="status-pill"><span /> Best route</span>
            <h1>Leave at 7:28 <small>AM</small></h1>
            <p>45 min drive · 10 min parking buffer</p>
          </div>
          <div className="arrival-time"><span>ARRIVE</span><strong>8:23</strong><small>7 min early</small></div>
        </div>
        <div className="route-notice"><span className="traffic-dot" /><p><strong>Moderate traffic</strong> on Highway 1 adds about 8 min</p></div>
        <div className="route-options">
          <p className="overline">ROUTE OPTIONS</p>
          {[
            { title: "Via Highway 1 E", detail: "Fastest · 28 km", time: "45 min", note: "Moderate traffic" },
            { title: "Via Hastings St", detail: "22 km · No tolls", time: "52 min", note: "7 min slower" },
          ].map((option, index) => (
            <button key={option.title} className={`route-option ${route === index ? "selected" : ""}`} onClick={() => setRoute(index)}>
              <span className="radio"><i /></span>
              <span className="grow"><strong>{option.title}</strong><small>{option.detail}</small><em>{option.note}</em></span>
              <strong>{option.time}</strong>
            </button>
          ))}
        </div>
        <button className="primary-button"><Icon name="car" /> Start preview</button>
      </main>
    </div>
  );
}

function Alerts() {
  const [settings, setSettings] = useState({ reminders: true, traffic: true, changes: false, sound: true });
  const update = (key: keyof typeof settings) => setSettings({ ...settings, [key]: !settings[key] });
  return (
    <div className="screen">
      <TopBar title="Alerts" />
      <main className="content">
        <div className="page-intro"><h1>Stay one step ahead</h1><p>Timely updates, only when they’re useful.</p></div>
        <section className="alert-card urgent">
          <span className="alert-icon"><Icon name="traffic" /></span>
          <div className="grow"><div className="alert-time">8 MIN AGO</div><h2>Traffic building earlier</h2><p>Highway 1 is slowing near Grandview. Your leave time moved 6 minutes earlier.</p></div>
          <span className="unread" />
        </section>
        <section className="alert-card">
          <span className="alert-icon blue"><Icon name="clock" /></span>
          <div className="grow"><div className="alert-time">YESTERDAY</div><h2>Perfect timing</h2><p>You arrived at BCIT at 8:24 AM — right on schedule.</p></div>
        </section>
        <p className="section-label">NOTIFICATION PREFERENCES</p>
        <section className="settings-card">
          {[
            ["reminders", "Departure reminders", "Get notified when it’s time to leave", "clock"],
            ["traffic", "Sudden traffic alerts", "Changes that affect your departure", "traffic"],
            ["changes", "Weekly insights", "A summary of commute trends", "calendar"],
            ["sound", "Sounds & vibration", "Use your device alert settings", "bell"],
          ].map(([key, title, detail, icon], index) => (
            <div className="setting-row" key={key}>
              <span className="setting-icon"><Icon name={icon as IconName} /></span>
              <div className="grow"><strong>{title}</strong><small>{detail}</small></div>
              <Toggle active={settings[key as keyof typeof settings]} onClick={() => update(key as keyof typeof settings)} label={`Toggle ${title}`} />
              {index < 3 && <span className="row-divider" />}
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}

function Profile({ onLogout }: { onLogout: () => void }) {
  const [smart, setSmart] = useState(true);
  return (
    <div className="screen">
      <TopBar title="Profile" />
      <main className="content">
        <section className="profile-card">
          <div className="profile-avatar">AM</div>
          <div><h1>Alex Morgan</h1><p>alex.morgan@example.com</p></div>
          <button className="edit-profile" aria-label="Edit profile"><Icon name="edit" size={17} /></button>
        </section>
        <p className="section-label">TRAVEL PREFERENCES</p>
        <section className="settings-card">
          <button className="setting-row interactive">
            <span className="setting-icon"><Icon name="car" /></span>
            <div className="grow"><strong>Default travel mode</strong><small>Driving</small></div><Icon name="chevron" />
          </button>
          <button className="setting-row interactive">
            <span className="setting-icon"><Icon name="clock" /></span>
            <div className="grow"><strong>Default arrival buffer</strong><small>10 minutes</small></div><Icon name="chevron" />
          </button>
          <div className="setting-row">
            <span className="setting-icon"><Icon name="traffic" /></span>
            <div className="grow"><strong>Smart adjustments</strong><small>Learn from my usual travel time</small></div>
            <Toggle active={smart} onClick={() => setSmart(!smart)} label="Toggle smart adjustments" />
          </div>
        </section>
        <p className="section-label">ACCOUNT</p>
        <section className="settings-card">
          <button className="setting-row interactive"><span className="setting-icon"><Icon name="settings" /></span><div className="grow"><strong>App settings</strong><small>Units, language and appearance</small></div><Icon name="chevron" /></button>
          <button className="setting-row interactive"><span className="setting-icon"><Icon name="shield" /></span><div className="grow"><strong>Privacy & data</strong><small>Manage location and saved data</small></div><Icon name="chevron" /></button>
          <button className="setting-row interactive danger" onClick={onLogout}><span className="setting-icon"><Icon name="logout" /></span><div className="grow"><strong>Sign out</strong></div></button>
        </section>
        <p className="version">Easeway for iOS & Android · v1.0</p>
      </main>
    </div>
  );
}

function BottomNav({ screen, navigate }: { screen: Screen; navigate: (screen: Screen) => void }) {
  const items: { screen: Screen; icon: IconName; label: string }[] = [
    { screen: "home", icon: "home", label: "Home" },
    { screen: "commutes", icon: "calendar", label: "Commutes" },
    { screen: "alerts", icon: "bell", label: "Alerts" },
    { screen: "profile", icon: "user", label: "Profile" },
  ];
  return (
    <nav className="bottom-nav">
      {items.map(item => (
        <button key={item.screen} className={screen === item.screen ? "active" : ""} onClick={() => navigate(item.screen)}>
          <span className="nav-icon"><Icon name={item.icon} /></span>
          <span>{item.label}</span>
          {item.screen === "alerts" && <i className="nav-dot" />}
        </button>
      ))}
    </nav>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [commutes, setCommutes] = useState(initialCommutes);
  const navigate = (next: Screen) => setScreen(next);
  const hasNav = ["home", "commutes", "alerts", "profile"].includes(screen);

  const saveCommute = () => {
    if (!commutes.some(c => c.name === "Campus")) {
      setCommutes([...commutes, { id: 4, name: "Campus", destination: "BCIT Burnaby", days: "Mon–Fri", time: "8:30 AM", duration: "45 min", enabled: true, icon: "briefcase" }]);
    }
    setScreen("commutes");
  };

  return (
    <div className="app-stage">
      <aside className="brand-panel">
        <Logo />
        <div className="brand-copy">
          <span className="eyebrow">Your day, right on time</span>
          <h1>Less waiting.<br />Less rushing.<br /><em>More ease.</em></h1>
          <p>Personalized departure times that adapt to live traffic and the way you travel.</p>
        </div>
        <div className="brand-stat">
          <span><Icon name="check" /></span>
          <div><strong>7:28 AM</strong><small>Your ideal departure time</small></div>
        </div>
      </aside>
      <div className="phone-shell">
        <div className="status-bar"><span>9:41</span><div className="status-icons"><i /><i /><b /></div></div>
        <div className="app-viewport">
          {screen === "login" && <Login onEnter={() => navigate("home")} />}
          {screen === "home" && <Dashboard navigate={navigate} />}
          {screen === "commutes" && <Commutes navigate={navigate} commutes={commutes} setCommutes={setCommutes} />}
          {screen === "add" && <AddCommute onBack={() => navigate("commutes")} onSave={saveCommute} />}
          {screen === "route" && <RouteDetails onBack={() => navigate("home")} />}
          {screen === "alerts" && <Alerts />}
          {screen === "profile" && <Profile onLogout={() => navigate("login")} />}
        </div>
        {hasNav && <BottomNav screen={screen} navigate={navigate} />}
        <div className="home-indicator"><span /></div>
      </div>
    </div>
  );
}
